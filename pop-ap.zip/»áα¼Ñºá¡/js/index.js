$(".btns").on('click', function () {
  console.log('cliced');
  $(".modals").addClass('active');
});
$(".bg-popap, .fa.fa-times").on('click', function () {
  $(".modals").removeClass('active');
});
